let C1 = document.getElementById("clubs1");
let C2 = document.getElementById("clubs2");
let C3 = document.getElementById("clubs3");
let C4 = document.getElementById("clubs4");
let C5 = document.getElementById("clubs5");
let C6 = document.getElementById("clubs6");
let C7 = document.getElementById("clubs7");
let C8 = document.getElementById("clubs8");
let C9 = document.getElementById("clubs9");
let C10 = document.getElementById("clubs10");
let C11 = document.getElementById("clubs11");
let C12 = document.getElementById("clubs12");
let C13 = document.getElementById("clubs13");
// Clubs
let D1 = document.getElementById("diamonds1");
let D2 = document.getElementById("diamonds2");
let D3 = document.getElementById("diamonds3");
let D4 = document.getElementById("diamonds4");
let D5 = document.getElementById("diamonds5");
let D6 = document.getElementById("diamonds6");
let D7 = document.getElementById("diamonds7");
let D8 = document.getElementById("diamonds8");
let D9 = document.getElementById("diamonds9");
let D10 = document.getElementById("diamonds10");
let D11 = document.getElementById("diamonds11");
let D12 = document.getElementById("diamonds12");
let D13 = document.getElementById("diamonds13");
//diamonds
let H1 = document.getElementById("hearts1");
let H2 = document.getElementById("hearts2");
let H3 = document.getElementById("hearts3");
let H4 = document.getElementById("hearts4");
let H5 = document.getElementById("hearts5");
let H6 = document.getElementById("hearts6");
let H7 = document.getElementById("hearts7");
let H8 = document.getElementById("hearts8");
let H9 = document.getElementById("hearts9");
let H10 = document.getElementById("hearts10");
let H11 = document.getElementById("hearts11");
let H12 = document.getElementById("hearts12");
let H13 = document.getElementById("hearts13");
//hearts
let S1 = document.getElementById("spades1");
let S2 = document.getElementById("spades2");
let S3 = document.getElementById("spades3");
let S4 = document.getElementById("spades4");
let S5 = document.getElementById("spades5");
let S6 = document.getElementById("spades6");
let S7 = document.getElementById("spades7");
let S8 = document.getElementById("spades8");
let S9 = document.getElementById("spades9");
let S10 = document.getElementById("spades10");
let S11 = document.getElementById("spades11");
let S12 = document.getElementById("spades12");
let S13 = document.getElementById("spades13");
//spades

let toggle = 0;


function ShuffleFunction(){
    let cardshuffle = 
    ["clubs-1.svg","clubs-2.svg","clubs-3.svg","clubs-4.svg","clubs-5.svg","clubs-6.svg","clubs-7.svg",
    "clubs-8.svg","clubs-9.svg","clubs-10.svg","clubs-11.svg","clubs-12.svg","clubs-13.svg",
    
    "diamonds-1.svg","diamonds-2.svg","diamonds-3.svg","diamonds-4.svg","diamonds-5.svg","diamonds-6.svg","diamonds-7.svg",
    "diamonds-8.svg","diamonds-9.svg","diamonds-10.svg","diamonds-11.svg","diamonds-12.svg","diamonds-13.svg",
    
    "hearts-1.svg","hearts-2.svg","hearts-3.svg","hearts-4.svg","hearts-5.svg","hearts-6.svg","hearts-7.svg",
    "hearts-8.svg","hearts-9.svg","hearts-10.svg","hearts-11.svg","hearts-12.svg","hearts-13.svg",
    
    "spades-1.svg","spades-2.svg","spades-3.svg","spades-4.svg","spades-5.svg","spades-6.svg","spades-7.svg","spades-8.svg",
    "spades-9.svg","spades-10.svg","spades-11.svg","spades-12.svg","spades-13.svg"];
          
    shuffleArray(cardshuffle);
   
    if(cardshuffle[0]){ C1.src = cardshuffle[0];};
    if(cardshuffle[1]){ C2.src = cardshuffle[1];};
    if(cardshuffle[2]){ C3.src = cardshuffle[2];};
    if(cardshuffle[3]){ C4.src = cardshuffle[3];};
    if(cardshuffle[4]){ C5.src = cardshuffle[4];};
    if(cardshuffle[5]){ C6.src = cardshuffle[5];};
    if(cardshuffle[6]){ C7.src = cardshuffle[6];};
    if(cardshuffle[7]){ C8.src = cardshuffle[7];};
    if(cardshuffle[8]){ C9.src = cardshuffle[8];};
    if(cardshuffle[9]){ C10.src = cardshuffle[9];};
    if(cardshuffle[10]){ C11.src = cardshuffle[10];};
    if(cardshuffle[11]){ C12.src = cardshuffle[11];};
    if(cardshuffle[12]){ C13.src = cardshuffle[12];};

    if(cardshuffle[13]){ D1.src = cardshuffle[13];};
    if(cardshuffle[14]){ D2.src = cardshuffle[14];};
    if(cardshuffle[15]){ D3.src = cardshuffle[15];};
    if(cardshuffle[16]){ D4.src = cardshuffle[16];};
    if(cardshuffle[17]){ D5.src = cardshuffle[17];};
    if(cardshuffle[18]){ D6.src = cardshuffle[18];};
    if(cardshuffle[19]){ D7.src = cardshuffle[19];};
    if(cardshuffle[20]){ D8.src = cardshuffle[20];};
    if(cardshuffle[21]){ D9.src = cardshuffle[21];};
    if(cardshuffle[22]){ D10.src = cardshuffle[22];};
    if(cardshuffle[23]){ D11.src = cardshuffle[23];};
    if(cardshuffle[24]){ D12.src = cardshuffle[24];};
    if(cardshuffle[25]){ D13.src = cardshuffle[25];};
    
    if(cardshuffle[26]){ H1.src = cardshuffle[26];};
    if(cardshuffle[27]){ H2.src = cardshuffle[27];};
    if(cardshuffle[28]){ H3.src = cardshuffle[28];};
    if(cardshuffle[29]){ H4.src = cardshuffle[29];};
    if(cardshuffle[30]){ H5.src = cardshuffle[30];};
    if(cardshuffle[31]){ H6.src = cardshuffle[31];};
    if(cardshuffle[32]){ H7.src = cardshuffle[32];};
    if(cardshuffle[33]){ H8.src = cardshuffle[33];};
    if(cardshuffle[34]){ H9.src = cardshuffle[34];};
    if(cardshuffle[35]){ H10.src = cardshuffle[35];};
    if(cardshuffle[36]){ H11.src = cardshuffle[36];};
    if(cardshuffle[37]){ H12.src = cardshuffle[37];};
    if(cardshuffle[38]){ H13.src = cardshuffle[38];};
    
    if(cardshuffle[39]){ S1.src = cardshuffle[39];};
    if(cardshuffle[40]){ S2.src = cardshuffle[40];};
    if(cardshuffle[41]){ S3.src = cardshuffle[41];};
    if(cardshuffle[42]){ S4.src = cardshuffle[42];};
    if(cardshuffle[43]){ S5.src = cardshuffle[43];};
    if(cardshuffle[44]){ S6.src = cardshuffle[44];};
    if(cardshuffle[45]){ S7.src = cardshuffle[45];};
    if(cardshuffle[46]){ S8.src = cardshuffle[46];};
    if(cardshuffle[47]){ S9.src = cardshuffle[47];};
    if(cardshuffle[48]){ S10.src = cardshuffle[48];};
    if(cardshuffle[49]){ S11.src = cardshuffle[49];};
    if(cardshuffle[50]){ S12.src = cardshuffle[50];};
    if(cardshuffle[51]){ S13.src = cardshuffle[51];};



    let facts = ["Over the centuries, decks of cards have come in variations of 24, 36, 40, 48, and just about any amount in between. No one can say for sure just why 52 has become the most common deck size, other than that due to English and French colonialism, the French deck (with 52 cards) was able to spread around the world quite easily.",
                 "Scholars have argued that the “game of leaves,” played in China in the 9th century, was the earliest card game.",
                 "The clubs, diamonds, hearts and spades that grace modern card decks are the same ones that appeared on French decks hundreds of years ago.",
                 "Obviously the values of different cards vary slightly depending on the type of card game you’re playing, but there are also cultural influences that affect how much a card is worth. The “British Rule,” for example, transfers the highest card value to the queen when a queen is in power in the United Kingdom. Makes sense, doesn’t it?"]
    
    let factinfo = document.getElementById("Factsinfo");
    shuffleFacts(facts);
    
    if (facts[0]){
        factinfo.innerHTML = facts[0];

    }
    
}

function ShowHideFunction(){
    
    let showHide = document.getElementById("cards");

    if (toggle === 0){
        showHide.classList.remove("showHideCards2");
        toggle++;
        console.log(toggle);
        showHide.classList.add("showHideCards");
    }
    
    else if (toggle === 1){
        showHide.classList.remove("showHideCards");
        toggle--;
        console.log(toggle);
        showHide.classList.add("showHideCards2");
    }

}

    
function MagicFunction(){

    let ordered = 
    ["clubs-1.svg","clubs-2.svg","clubs-3.svg","clubs-4.svg","clubs-5.svg","clubs-6.svg","clubs-7.svg",
    "clubs-8.svg","clubs-9.svg","clubs-10.svg","clubs-11.svg","clubs-12.svg","clubs-13.svg",
    
    "diamonds-1.svg","diamonds-2.svg","diamonds-3.svg","diamonds-4.svg","diamonds-5.svg","diamonds-6.svg","diamonds-7.svg",
    "diamonds-8.svg","diamonds-9.svg","diamonds-10.svg","diamonds-11.svg","diamonds-12.svg","diamonds-13.svg",
    
    "hearts-1.svg","hearts-2.svg","hearts-3.svg","hearts-4.svg","hearts-5.svg","hearts-6.svg","hearts-7.svg",
    "hearts-8.svg","hearts-9.svg","hearts-10.svg","hearts-11.svg","hearts-12.svg","hearts-13.svg",
    
    "spades-1.svg","spades-2.svg","spades-3.svg","spades-4.svg","spades-5.svg","spades-6.svg","spades-7.svg","spades-8.svg",
    "spades-9.svg","spades-10.svg","spades-11.svg","spades-12.svg","spades-13.svg"];

    if(ordered[0]){ C1.src = ordered[0];};
    if(ordered[1]){ C2.src = ordered[1];};
    if(ordered[2]){ C3.src = ordered[2];};
    if(ordered[3]){ C4.src = ordered[3];};
    if(ordered[4]){ C5.src = ordered[4];};
    if(ordered[5]){ C6.src = ordered[5];};
    if(ordered[6]){ C7.src = ordered[6];};
    if(ordered[7]){ C8.src = ordered[7];};
    if(ordered[8]){ C9.src = ordered[8];};
    if(ordered[9]){ C10.src = ordered[9];};
    if(ordered[10]){ C11.src = ordered[10];};
    if(ordered[11]){ C12.src = ordered[11];};
    if(ordered[12]){ C13.src = ordered[12];};

    if(ordered[13]){ D1.src = ordered[13];};
    if(ordered[14]){ D2.src = ordered[14];};
    if(ordered[15]){ D3.src = ordered[15];};
    if(ordered[16]){ D4.src = ordered[16];};
    if(ordered[17]){ D5.src = ordered[17];};
    if(ordered[18]){ D6.src = ordered[18];};
    if(ordered[19]){ D7.src = ordered[19];};
    if(ordered[20]){ D8.src = ordered[20];};
    if(ordered[21]){ D9.src = ordered[21];};
    if(ordered[22]){ D10.src = ordered[22];};
    if(ordered[23]){ D11.src = ordered[23];};
    if(ordered[24]){ D12.src = ordered[24];};
    if(ordered[25]){ D13.src = ordered[25];};
    
    if(ordered[26]){ H1.src = ordered[26];};
    if(ordered[27]){ H2.src = ordered[27];};
    if(ordered[28]){ H3.src = ordered[28];};
    if(ordered[29]){ H4.src = ordered[29];};
    if(ordered[30]){ H5.src = ordered[30];};
    if(ordered[31]){ H6.src = ordered[31];};
    if(ordered[32]){ H7.src = ordered[32];};
    if(ordered[33]){ H8.src = ordered[33];};
    if(ordered[34]){ H9.src = ordered[34];};
    if(ordered[35]){ H10.src = ordered[35];};
    if(ordered[36]){ H11.src = ordered[36];};
    if(ordered[37]){ H12.src = ordered[37];};
    if(ordered[38]){ H13.src = ordered[38];};
    
    if(ordered[39]){ S1.src = ordered[39];};
    if(ordered[40]){ S2.src = ordered[40];};
    if(ordered[41]){ S3.src = ordered[41];};
    if(ordered[42]){ S4.src = ordered[42];};
    if(ordered[43]){ S5.src = ordered[43];};
    if(ordered[44]){ S6.src = ordered[44];};
    if(ordered[45]){ S7.src = ordered[45];};
    if(ordered[46]){ S8.src = ordered[46];};
    if(ordered[47]){ S9.src = ordered[47];};
    if(ordered[48]){ S10.src = ordered[48];};
    if(ordered[49]){ S11.src = ordered[49];};
    if(ordered[50]){ S12.src = ordered[50];};
    if(ordered[51]){ S13.src = ordered[51];};
    
}

function shuffleArray(array){

    for (let i = array.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        let temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    return array;
}

function shuffleFacts(array){
    
    for (let i = array.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        let temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    return array;
}
    
        